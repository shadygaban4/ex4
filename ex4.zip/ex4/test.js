
//סעיד ו שאדי

const fs = require('fs'); // Import module
const path = require('path');

const dirPath = path.join(__dirname, '/text');


// קריאת הקבצים שנקלתו
const textIn1 = fs.readFileSync(`${dirPath}/input1.txt`, 'utf-8');
const textIn2 = fs.readFileSync(`${dirPath}/input2.txt`, 'utf-8');
const textIn3 = fs.readFileSync(`${dirPath}/input3.txt`, 'utf-8');

// סמ את המידע ב מחרוזות
const arr1 = textIn1.split('\r\n');
const arr2 = textIn2.split('\r\n');
const arr3 = textIn3.split('\r\n');

// מסדירת את השורות לפי שבקשו בתוך משתנה חדש
let new_str = '';
for (let i = 0; i < arr1.length; i++) {
  new_str += arr1[i] + '\n' + arr2[i] + '\n' + arr3[i] + '\n';
}


//יתסרנו משתנה שסמנו בו הערכים שרותסים לסים בתוך קובץ שרוצם ליצר
const textOut = `the text was: ${new_str}`;
console.log(textOut);

// יצרת הקובץ
fs.writeFileSync(`${dirPath}/output.txt`, textOut);



